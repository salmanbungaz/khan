# termux shell installation and setup
#
# 1. install termux from play store
# 2. open termux and type command below:
#	$ termux-setup-storage
#	$ pkg install python2
#	$ pkg install python2-pip
#	$ pip2 install colorama
#	$ pip2 install requests
#	$ pip2 install python-socketio[client]
#	$ cp storage/shared/downloads/miggi-0.0.2.tar.gz ./
#	$ tar -xvzf miggi-0.0.2.tar.gz
#	$ cd miggi
#	$ chmod +x miggi.py
#	$ python2 miggi.py

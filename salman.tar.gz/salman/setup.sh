#!/bin/sh
apt-get install python2 python2-pip
pip install requests urllib3 colorama python-socketio[client]

#!/usr/bin/python
# --------------------------------
# simple miggi bot on python
# use this script at your own risk
# migbotica@gmail.com
# --------------------------------
# require python 2.7 and libs:
# - requests
# - urllib3
# - colorama
# - python-socketio[client]
# --------------------------------

import urllib3
import requests
import socketio
import random
import json
import time
import sys
from io import open
from colorama import init, Fore
from os.path import dirname, realpath

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
init(autoreset=True)
__DEBUG__= True
__PING__= True
timestart= time.time()

class BotCommand:
	pass

#utility functions
def _e(msg):
	caller= sys._getframe(1).f_code.co_name
	print Fore.RED+"{}[error] {}, {}.".format(time.strftime("%d-%m-%Y %H:%M:%S"),caller, msg)

def _d(msg):
	if(__DEBUG__):
		caller= sys._getframe(1).f_code.co_name
		print Fore.YELLOW+"[{}][debug] {}, {}.".format(time.strftime("%d-%m-%Y %H:%M:%S"),caller, msg)

def _i(msg):
		print Fore.GREEN+"[{}][info]: {}.".format(time.strftime("%d-%m-%Y %H:%M:%S"),msg)

def _flip(var):
	return (not var)

def _split(text, n):
	text= text.split("\x20")
	chunk=""
	result=[]
	count= len(text)
	for i in range(count):
		text[i]=text[i]+"\x20"
		if i==(count-1):
			result.append(chunk+text[i])
		elif (len(chunk)+len(text[i]))<n:
			chunk+= text[i]
		else:
			result.append(chunk)
			chunk= text[i]
	_d(result)
	return result

def cmd_register(func, fcallback):
	if(callable(fcallback) and not hasattr(cmd, func)): setattr(cmd,func,fcallback)

def _login_worker(username, password):
	global sio
	data= {	"username": username,
		"password": password,
		"invisible":False,
		"version": "2.0"
		}
	try:
		r = requests.post("http://chat.miggi.id/api/login", json=data, timeout=5)
		sio.sleep(random.random())
		session= r.json()
		if r.status_code==200:
			if session["success"]:
				kicker["session"][username]= "Bearer {}".format(session["data"]["token"])
				_i("HTTP {}: {} login success".format(username, r.status_code))
			else:
				_e("HTTP {}: {} login failed".format(r.status_code, username))
	except Exception as err:
		_e("HTTP {}".format(err))

def _enter_worker(token, room):
	global sio
	formdata={"roomname": room}
	head={"Authorization": token}
	try:
		r = requests.post("http://chat.miggi.id/api/join-room", headers=head, json=formdata, timeout=5)
		sio.sleep(random.random())
		_i("HTTP {}".format(r.status_code))
	except Exception as err:
		_e(err)

def _left_worker(token, room):
	global sio
	formdata={"roomname": room}
	head={"Authorization": token}
	try:
		r = requests.post("http://chat.miggi.id/api/leave-room", headers=head, json=formdata, timeout=3)
		sio.sleep(random.random())
		_i("HTTP {}".format(r.status_code))
	except Exception as err:
		_e(err)

def _kick_worker(target, token):
	global sio, kicker
	head= {"Authorization": token}
	_i("target:{} room:{}".format(target, kicker["room"]))
	formdata= {
		"username": target,
		"roomname": kicker["room"]
		}
	try:
		r = requests.post("http://chat.miggi.id/api/kick", headers=head, data=formdata, timeout=3)
		sio.sleep(random.random())
		_d("HTTP {}".format(r.text))
	except Exception as err:
		_e(err)

# Bot Timer Task
def autopost(interval):
	global sio, chat, bot
	if not sio.connected:
		return
	msg= random.choice(chat["textpost"])
	if bot["session"]["users"] != []:
		u=random.choice(bot['session']['users'])
		msg= msg.replace("$u", u)
	else:
		msg= msg.replace("$u", "")

	if(bot["config"]["autopost"] and sio.connected):
		try:
			for room in bot["session"]["rooms"]:
				post_text(room, msg)
		except Exception as err:
			_e(err)
		sio.sleep(interval)
		autopost(interval)

def _ping_worker(token):
	global sio,kicker
	head= {"Authorization": token}
	try:
		r=requests.get("http://chat.miggi.id/api/keep-alive", headers=head, timeout=3)
		_i("HTTP {}".format(r.status_code))
	except Exception as err:
		_e(err)
	sio.sleep(random.random())

def ping(interval):
	global bot, sio
	if(sio.connected):
		try:
			r = requests.get("http://chat.miggi.id/api/keep-alive", headers=bot["headers"], timeout=3)
			_d("HTTP {}-{}".format(r.status_code, r.text))
		except Exception as err:
			_e(err)
		sio.sleep(interval)
		if len(kicker["session"]) > 0:
			for x in kicker["session"]:
				sio.start_background_task(_ping_worker, kicker["session"][x])
		ping(interval)

# Bot application interface
def help():
	return "migpy v0.0.1 [.go|.x|.spy|.add|.del|.text|.wb|.load|.enter|.left]"

def set_autowb():
	bot["config"]["autowb"]= _flip(bot["config"]["autowb"])
	return "autowb: {}".format(str(bot["config"]["autowb"]))

def set_autopost():
	bot["config"]["autopost"]= _flip(bot["config"]["autopost"])
	return "autopost: {}".format(str(bot["config"]["autopost"]))

def add_author(user):
	if user not in bot["config"]["author"]:
		bot["config"]["author"].append(user)
		return "{} added to author".format(user)

def del_author(user):
	if user in bot["config"]["author"]:
		bot["config"]["author"].remove(user)
		return "{} removed from author".format(user)

def add_keyword(keyword, respond):
	if keyword in chat["respond"]:
		if type(chat["respond"]["keyword"])==type([]):
			chat["respond"]["keyword"].append(respond)
		chat["respond"]["keyword"]= [respond]
		return "keyword added"
def load():
	global sio,kicker
	for username in kicker["voters"]:
		sio.start_background_task(_login_worker, username, kicker["voters"][username])

def enter(room):
	global sio,kicker
	kicker["room"]= room
	if len(kicker["session"])==0:
		return "multiset not logged in"
	for multi in kicker["session"]:
		sio.start_background_task(_enter_worker, kicker["session"][multi], room)

def kick(target):
	global sio,kicker
	if not kicker["room"]: return "not in room"
	if len(kicker["session"])==0:
		return "multiset not logged in"
	for multi in kicker["session"]:
		sio.start_background_task(_kick_worker, target, kicker["session"][multi])

def left(room):
	global sio, kicker
	kicker["room"]= None
	if len(kicker["session"])==0:
		return "multiset not logged in"
	for multi in kicker["session"]:
		sio.start_background_task(_left_worker, kicker["session"][multi], room)

def stat():
	return "rooms:{} | author:{} | respond: {} | autowb: {}".format(\
	bot["session"]["rooms"], bot["config"]["author"],\
	bot["config"]["respond"], bot["config"]["autowb"])

def spy(roomname):
	roomname= roomname.lower()
	formdata= {"roomname": roomname}
	try:
		r = requests.post("http://chat.miggi.id/api/room-users", headers=bot["headers"], json=formdata, timeout=3)
		result= r.json()
		_d("HTTP {}".format(r.status_code))
		if(result["success"]):
			users=[]
			for usr in result["data"]["users"]:
				users.append(usr["username"])
			users= ", ".join(users)
			users= "{} [{}]: {}".format(roomname, result["data"]["count"], users)
			_i("{} [{}] users".format(roomname, result["data"]["count"]))
			return users.rstrip(", ")
		else:
			_i("{} [failed]".format(roomname))
			return "{} [failed]".format(roomname)
	except Exception as err:
		_e(err)

def post_leaveroom(roomname):
	global bot
	roomname=roomname.lower()
	formdata= {"roomname": roomname}
	if roomname in bot["session"]["rooms"]:
		bot["session"]["rooms"].remove(roomname)
	try:
		r = requests.post("http://chat.miggi.id/api/leave-room", headers=bot["headers"], json=formdata, timeout=3)
		_d("HTTP {}".format(r.status_code))
		if r.status_code==200:
			_i("leave room "+roomname)
	except Exception as err:
		_e(err)

def post_joinroom(roomname):
	global bot
	roomname= roomname.lower()
	formdata={"roomname": roomname}
	try:
		if roomname in bot["session"]["rooms"]:
			return "udah di {} bos:D".format(roomname)
		r = requests.post("http://app.miggi.id/api/join-room", headers=bot["headers"], json=formdata, timeout=7)
		result= r.json()
		_d("HTTP {}".format(r.status_code))
		if result["success"]:
			_i("join room "+roomname)
			bot["session"]["rooms"].append(roomname)
			return "meluncur ke {} :D".format(roomname)
		else:
			return repr(result)
	except Exception as err:
		_e(err)

def post_text(roomname, message, msgtype="room"):
	global bot
	formdata= {
		"to": roomname,
		"type": msgtype,
		"text": message
		}
	try:
		r = requests.post("http://chat.miggi.id/api/send-text", headers=bot["headers"], json=formdata, timeout=3)
		result= r.json()
		bot["session"]["lastchat"]= time.time()
		_d("HTTP {}: {}-{}".format(r.status_code, roomname, msgtype))
	except Exception as err:
		_e(err)


# event handler
def on_connect():
	pass

def on_disconnect():
	_e("SocketIO disconnected.")

def on_notify(channel, message):
	global sio
	_i("{} : {}".format(channel, message))
	if(message["message"]=='logout'):
		sio.disconnect()

def on_subscription_error(channel, message):
	global sio
	_i("{} : {}".format(channel, message))
	sio.disconnet()

def cmd_handler(event):
	global cmd
	data= event["message"]["text"].split()
	f= data[0].replace('.', '')
	if(hasattr(cmd, f) and callable(getattr(cmd, f))):
		data.remove(data[0])
		args= ('\x20'.join(data)).lower()
		try:
			_d("cmd {} invoked.\nargs: {}".format(f, args))
			if len(args)==0:
				if (f=="spy" or f=="x" or f=="enter" or f=="left"):
					args= event["message"]["to"]
					return getattr(cmd,f)(args)
				else:
					return getattr(cmd,f)()
			else:
				return getattr(cmd,f)(args)
		except Exception as err:
			_e(err)
	return True

def chat_handler(channel, data):
	global bot

	# message from room
	if(data["message"]["from"]==data["message"]["to"]):
		room_handler(data)
		return
	if data["message"]["type"]=="private":
		dst= data["message"]["from"]
	else:
		dst= data["message"]["to"]
	src= data["message"]["from"]
	msgtype= data["message"]["type"]
	msg= data["message"]["text"].encode("utf-8")
	mode= data["message"]["mode"]
	_d("mode: {}\nfrom: {}\nmessage: {}".format(mode, src, repr(msg)))

	#command handler goes here
	if (src in bot["config"]["author"] and msg.startswith(".")):
		result= cmd_handler(data)
		if type(result)==type(""):
			if len(result)>255:
				result=_split(result, 255)
				for chunk in result:
					post_text(dst, chunk, msgtype)
			else:
				post_text(dst, result, msgtype)
		return

	if (time.time()-bot["session"]["lastchat"] < bot["config"]["safedelay"]) or (not bot["config"]["respond"]) \
	or (mode!="chat") or (msgtype!="room"):
		return

	# pass to chat respond
	if src not in bot['session']['users']:
		bot['session']['users'].append(src)
	msg= msg.split("\x20")
	for word in msg:
		if chat["respond"].has_key(word):
			text= chat["respond"][word]
			if type(chat["respond"][word])==type([]):
				text= random.choice(chat["respond"][word])
			text= text.replace('$u', src)
			post_text(dst, text)
			_d("\nrespond to user: {}".format(text))
			break

def room_handler(data):
	global chat,bot
	try:
		if data["message"]["text"].find("vote to kick {}".format(bot["login"]["username"]))> -1:
			post_leaveroom(data["message"]["to"])
			sio.sleep(60)
			post_joinroom(data["message"]["to"])
			return
		if ((time.time()-bot["session"]["lastwb"]) < bot["config"]["safedelay"]) or not bot["config"]["autowb"]:
			return

		text= data["message"]["text"].split()
		if(text[-1]== "left"):
			resp= random.choice(chat['autolv'])
			if text[0] in bot["session"]["users"]:
				bot["session"]["users"].remove(text[0])
		elif(text[0]!=bot["login"]["username"] and text[-1]== "entered"):
			if text[0] not in bot["session"]["users"]:
				bot["session"]["users"].append(text[0])
			resp= random.choice(chat['autowb'])
		else:
			_i("room-event: {}".format(data["message"]["text"]))
			return

		resp= resp.replace('$u', text[0])
		_i("room-event {}".format(data["message"]["text"]))
		post_text(data["message"]["to"], resp)
		bot["session"]["lastwb"]=time.time()
	except Exception as err:
		_e(err)

# bot initialization
# load configuration
bot= chat= kicker={ }
cmd= BotCommand()
with open(dirname(realpath(__file__))+"/config", "r", encoding="utf-8") as cfg:
	try:
		bot= json.load(cfg)
		_i("bot config loaded")
	except ValueError:
		_e("config file corrupt")
		exit()

with open(dirname(realpath(__file__))+"/chat.bot", "r", encoding="utf-8") as chf:
	try:
		chat= json.load(chf)
		_i("chat file loaded")
	except ValueError:
		_e("chat file format error")
		exit()

with open(dirname(realpath(__file__))+"/troops", "r", encoding="utf-8") as trf:
	try:
		kicker= json.load(trf)
		_i("troops file loaded")
	except ValueError:
		_e("troops file format error")
		exit()

# request login process
try:
	r = requests.post("http://chat.miggi.id/api/login", headers=bot["headers"], json=bot["login"], timeout=3)
	session= r.json()
	if r.status_code==200:
		if session["success"]==False:
			_e("HTTP {}: login failed, {}".format(r.status_code, session["data"]["message"]))
			exit()
		with open(dirname(realpath(__file__))+"/cache","w") as f:
			f.write(session["data"]["token"])
			f.flush()
			f.close()
		bot["session"]["id"]= str(session["data"]["user"]["id"])
		bot["session"]["token"]= session["data"]["token"]
		bot["headers"]["Authorization"]= "Bearer "+ bot["session"]["token"]
		_i("HTTP {}: login success".format(r.status_code))
	else:
		_e("HTTP {}: {} ".format(r.status_code,r.text))
		exit()
except Exception as err:
	_e(err)
	exit()

# bot has been logged in, start socketio
# register command and event handler
sio= socketio.Client(reconnection=True, reconnection_attempts=3, logger=True, request_timeout=30, ssl_verify=False)
cmd_register('help', help)
cmd_register('spy', spy)
cmd_register('load', load)
cmd_register('enter', enter)
cmd_register('left', left)
cmd_register('kick', kick)
cmd_register('post', set_autopost)
cmd_register('wb', set_autowb)
cmd_register('add', add_author)
cmd_register('del', del_author)
cmd_register('stat', stat)
cmd_register('go', post_joinroom)
cmd_register('x', post_leaveroom)
sio.on("connect", on_connect)
sio.on("disconnect", on_disconnect)
sio.on("system-notification", on_notify)
sio.on("subscription_error", on_subscription_error)
sio.on("message-event", chat_handler)

try:
	sio.connect("http://chat.miggi.id:9119", headers=bot["headers"], transports="polling")
except Exception as err:
	_e("SocketIO failed to connect, {}".format(err))

post_joinroom(bot["config"]["room"])

#emitting subscribe to channel
ws_data={
"channel":"private-user-"+bot["session"]["id"],
"auth": {
	"headers": {
	"Authorization": bot["headers"]["Authorization"]
	}
}}
sio.emit("subscribe", ws_data)
sio.sleep(60)
sio.start_background_task(ping, 20)
sio.start_background_task(autopost, bot["config"]["postdelay"])
sio.wait()
# all belong to you
